<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en-GB" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="en-GB" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="en-GB" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en-GB" prefix="og: http://ogp.me/ns#"> <!--<![endif]-->
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="ie=edge" />
	  <title>Aberystwyth University: Best in the UK for student experience</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1" />
	  <meta http-equiv="content-language" name="language" content="en" /><!-- author -->
	  <meta name="author" content="Aberystwyth University Web Team" /><!-- description -->
	  <meta name="description" content="Awarded University of the Year for Teaching Quality, Aberystwyth University delivers cutting-edge research and teaching for undergraduate and postgraduate degrees."/>
	  <!-- keywords -->
	  <meta name="keywords" content="university, courses, undergraduate, undergrad, postgraduate, postgrad, entry, visiting, students, union, aberystwyth" />
	  <!--FB Link image -->
	  <meta property="og:image" content="/" /><!--FB Description -->
	  <meta property="og:description" content="Aberystwyth University- University of the Year for Teaching Quality. A TEF Gold and University of the Year for the second consecutive year, we deliver cutting-edge research and teaching." />
	  <link rel="apple-touch-icon" href="/img/apple-touch-icon.png" />
	  <!-- Place favicon.ico in the root directory -->
	  <link rel="stylesheet" href="/css2/app-v1.css" type="text/css" media="all" >
    <link rel="stylesheet" href="/css2/hp-v9.css" type="text/css" media="all" >

		<link rel="shortcut icon" type="image/x-icon" href="/img/icons/favicon.ico">
        <!-- Remove FOUC from no-js styling -->
        <script>(function(H){H.className=H.className.replace(/\bno-js\b/,'js')})(document.documentElement)</script>
		<script id="Cookiebot" src="https://consent.cookiebot.com/uc.js" data-cbid="49ca694e-5990-4dc8-9f93-00c2be21c0b1" type="text/javascript"  data-culture="EN" async></script>
        <!--[if lt IE 9]>
            <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <script src="/js2/ie8-plugins.min.js"></script>
        <![endif]-->
        <link rel="openorg" href="http://www.aber.ac.uk/en/research/equipment/OPD.ttl"/>
	<script type="text/plain" data-cookieconsent="marketing">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=  '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-TTBTCP');</script>
	 <meta name="facebook-domain-verification" content="blefh8ejjss9bv5rjnxr0i13o3z1t8" />
	 <meta name="google-site-verification" content="n01wtVXAm_s6X0SU0NfO4pQB6QyHdGNqjQiZxmAdn2g" />
	 <meta name="gecko_domain_verification" content="21VD00wnr7t0e00002zdizo65z"/>
    </head>
    <body>


        <div class="site-wrapper" id="page-start">
            <header role="banner" id="banner">
			<a id="skip-nav" href="#content-start" accesskey="S">Skip navigation &amp; go straight to the main content.</a><div class="inner"><a class="logo" href="/en/" accesskey="1" title="Aberystwyth University homepage"><picture><source type="image/svg+xml" srcset="/img/logo/au-logo.svg"/><img src="/img/logo/au-logo.png" srcset="/img/logo/au-logo.png, /img/logo/au-logo@2x.png 2x" alt="Aberystwyth University"/></picture></a><div class="logo-150 hidden"><a href="/en/about-us/150-anniversary/" title="Aberystwyth University 150th Anniversary"><picture><source type="image/svg+xml" srcset="/img/logo/150-logo.svg"/><img src="/img/logo/150-logo.png" srcset="/img/logo/150-logo.png, /img/logo/150-logo@2x.png 2x" alt="Aberystwyth University 150th Anniversary"/></picture></a></div><a id="nav-primary-toggle" href="#nav-primary" title="Menu"><span>Toggle menu</span></a><nav id="nav-primary"><!-- Different id to au-generic --><ul><li><a class="destination" href="https://www.aber.ac.uk/en/about-us/150-anniversary/">150<sup>th</sup> Anniversary</a></li><li><a class="destination" href="/en/study-with-us/?from=globalnav" accesskey="5">Study with us</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close Study with us"><span></span></a><ul class="child children"><li><a class="destination" href="/en/study-with-us/subjects/?from=globalnav">Our Subjects</a></li><li><a class="destination" href="//courses.aber.ac.uk/?from=globalnav">Course Search</a></li><li><a class="destination" href="/en/study-with-us/ug-studies/?from=globalnav">Undergraduate</a></li><li><a class="destination" href="/en/study-with-us/ug-studies/hub/?from=globalnav">Aber Hub</a></li><li><a class="destination" href="/en/study-with-us/pg-studies/?from=globalnav">Postgraduate</a></li><li><a class="destination" href="/en/study-with-us/open-days/?from=globalnav">Open Days</a></li><li><a class="destination" href="/en/study-with-us/fees/?from=globalnav">Fees and Finance</a></li><li><a class="destination" href="/en/study-with-us/prospectus/?from=globalnav">Prospectus</a></li><li><a class="destination" href="/en/study-with-us/accommodation/?from=globalnav">Accommodation</a></li><li><a class="destination" href="/en/study-with-us/global-opportunities/?from=globalnav">Global Opportunities</a></li><li><a class="destination" href="/en/study-with-us/online-distance/?from=globalnav">Online &amp; Distance Learning</a></li><li><a class="destination" href="/en/study-with-us/continuing-professional?from=globalnav">Continuous Professional Development</a></li><li><a class="destination" href="/en/study-with-us/mba?from=globalnav">Professional and Executive MBAs</a></li><li><a class="destination" href="/en/lifelong-learning/?from=globalnav">Lifelong Learning</a></li><li><a class="destination" href="/en/virtual-tour/?from=globalnav">Virtual Tour</a></li><li><a class="destination" href="/en/student/?from=globalnav">Current Students</a></li></ul></li><li><a class="destination" href="/en/study-with-us/international/?from=globalnav">International</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close International"><span></span></a><ul class="child children"><li><a class="destination" href="/en/study-with-us/international/how-to-apply/?from=globalnav">How to Apply</a></li><li><a class="destination" href="/en/study-with-us/international/countries/?from=globalnav">Your Country</a></li><li><a class="destination" href="/en/study-with-us/international/fees-scholarships/?from=globalnav">Fees &amp; Scholarships</a></li><li><a class="destination" href="/en/study-with-us/international/english-requirements/?from=globalnav">Your English</a></li><li><a class="destination" href="/en/sscs/visa-support-advice/?from=globalnav">Visa Support &amp; Advice Service</a></li><li><a class="destination" href="http://aberuni.cn"><span lang="zh-CN">亚伯大学中文官网</span></a></li></ul></li><li><a class="destination" href="/en/research/?from=globalnav" accesskey="7">Research</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close Research"><span></span></a><ul class="child children"><li><a class="destination" href="https://research.aber.ac.uk/portal/en/">Aberystwyth Research Portal</a></li><li><a class="destination" href="/en/expertise/?from=globalnav">Find an expert</a></li><li><a class="destination" href="/en/rbi/staff-students/?from=globalnav">Research Support</a></li><li><a class="destination" href="/en/rbi/business/?from=globalnav">Working with Us</a></li></ul></li><li><a class="destination" href="/en/news/?from=globalnav" accesskey="2">News</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close News"><span></span></a><ul class="child children"><li><a href="/en/news/?from=globalnav">Latest News</a></li><li><a href="/en/news/archive/?from=globalnav">News Archive</a></li></ul></li><li><a class="destination" href="/en/development/?from=globalnav">Alumni</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close Alumni"><span></span></a><ul class="child children"><li><a class="destination" href="/en/development/alumni/?from=globalnav">Alumni Services</a></li><li><a class="destination" href="/en/development/support/?from=globalnav">Support Aber</a></li><li><a class="destination" href="/en/development/alumni/update/?from=globalnav">Update your Details</a></li><li><a class="destination" href="/en/development/osa/?from=globalnav">Old Students&#039; Association</a></li></ul></li><li><a class="destination" href="/en/discover-aberystwyth/?from=globalnav">Discover Aberystwyth</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close Discover Aberystwyth"><span></span></a><ul class="child children"><li><a class="destination" href="https://www.aberystwythartscentre.co.uk/">Aberystwyth Arts Centre</a></li><li><a class="destination" href="/en/visitors/?from=globalnav">Conferences and Events</a></li><li><a class="destination" href="/en/discover-aberystwyth/life-on-campus/?from=globalnav">Life on Campus</a></li><li><a class="destination" href="/en/discover-aberystwyth/maps-travel/?from=globalnav">Maps and Travel</a></li><li><a class="destination" href="/en/music/?from=globalnav">Music at Aber</a></li><li><a class="destination" href="/en/sportscentre/?from=globalnav">Sports Centre</a></li></ul></li><li><a class="destination" href="/en/about-us/?from=globalnav">About Us</a><a class="toggle-section" href="javascript:void(0):" title="Expand or close About Us"><span></span></a><ul class="child children"><li><a class="destination" href="/en/about-us/departments-faculties/?from=globalnav">Departments and Faculties</a></li><li><a class="destination" href="/en/ccc/?from=globalnav">Coleg Cymraeg Cenedlaethol</a></li><li><a class="destination" href="/en/staff/?from=globalnav">Information for Staff</a></li><li><a class="destination" href="/en/maps-travel/?from=globalnav">Maps &amp; Travel</a></li><li><a class="destination" href="/en/hr/jobs/?from=globalnav">Jobs</a></li><li><a class="destination" href="/en/contact-us/?from=globalnav">Contact Us</a></li></ul></li></ul></nav><a id="search-toggle" href="javascript:void(0);" title="Search">Toggle Search</a><div id="search-overlay"><div><form id="search-site" action="/en/search/" method="post"><input id="global-search" type="search" name="query" placeholder="Search the site" aria-label="Search the site"><button type="submit">Go</button></form><a class="close-search" id="close-search" href="javascript:void(0);">Close</a><a class="hidden" href="/en/search/" accesskey="4"></a></div></div><p id="language-toggle" title="Newid iaith i Gymraeg" lang="cy" hreflang="cy"><a href="/cy/">Cymraeg</a></p></div>			 </header>
            <!-- END header -->

<main class="full-width">
<nav class="breadcrumbs">
				<div class="inner">
					<ol>
						<li>
							<a href="//www.aber.ac.uk/en/">Home</a>
						</li>
						<li>Error 404</li>
					</ol>
				</div>
			</nav>
			<div class="inner" id="content-start">
				<article class="content-primary normal fifty-forty">
					<div class="hero hero-w-image">
						<div class="hero-header">
							<header>
								<h1>Error 404</h1>
							</header>
                            <h2>Page not available</h2>
							<div class="image"></div>
						</div>
					</div>
                    
                    <style>
                        .hero-header h2 {
                            position: absolute;
                            top: 32%;
                            left: 6%;
                            z-index: 2;
                            font-size: 35px;
                            line-height: 1.1;
                            width: 300px;
                            margin-bottom: 0;
                        }
                        .hero .hero-header .image {
                            background-color: #f9f9f9;
                        }
                        #form-container h3 {
                            font-size: 23px;
                            margin-top: 20px;
                        }
                        .content-primary-main ul li {
                            margin: 0;
                            padding: 0;
                        }
                        #form-container p, #form-container label {
                            width: 85%;
                        }
                        #form-container {
                            border: 1px solid #e7e7e7;
                            padding-top: 20px;
                            padding-bottom: 20px;
                        }
                        .hero .hero-header .image {
                            background-position: right bottom;
                        }
                        @media only screen and (min-width: 500px) {
                            .hero-header h2 {
                                font-size: 45px;
                                top: 45%;
                                bottom: auto;
                            }
                        }
                        @media only screen and (min-width: 768px) {
                            .content-primary.normal .hero.hero-w-image .hero-header {
                                min-height: 430px;
                            }  
                        }
                        @media only screen and (min-width: 1024px) {
                            .hero-header h2 { 
                                top: 38%;
                                left: 6%;
                                font-size: 70px;
                                line-height: 1.1;
                                width: 450px;
                            }
                            #form-container h3 {
                                font-size: 28px;
                            }
                        }
                    </style>
                    
					<div class="content-primary-main">
                        <p class="lead">Sorry but the page you were trying to find is not available to view.<p><p> Why not choose one of the following pages to find what you're looking for?</p>
                        <ul>
                            <li><a href="/en/">AU Homepage</a></li>
                            <li><a href="https://courses.aber.ac.uk/">Courses</a></li>
                            <li><a href="/en/study-with-us/scholarships-funding/">Scholarships and Funding</a></li>
							<li><a href="/en/why-aber/">Why Aberystwyth?</a></li>
                            <li><a href="/en/departments/">Departments</a></li>
                        </ul>
					</div><!--EDITABLE-->
					<aside class="content-secondary">
                        <div id="form-container">
                        <h2>Report this error to us</h2>
<a name="feedback"></a>

<div id="form-10"><div id="en" class="wForm"><form id="enForm" name="theForm" class="au-form ui-dform-form" action="/en/form-manager/feedback/" method="post" novalidate="novalidate"><h3 id="html-1" name="1" class="ui-dform-h3">Your Details</h3><div class="form-group"><label for="1" class="ui-dform-label dform-label-required">Forename(s)</label><input type="text" id="1" data-sort="" name="1" required="required" class="ui-dform-text"></div><div class="form-group"><label for="2" class="ui-dform-label dform-label-required">Surname</label><input type="text" id="2" data-sort="" name="2" required="required" class="ui-dform-text"></div><div class="form-group"><label for="3" class="ui-dform-label dform-label-required">Email Address</label><input type="text" id="3" data-sort="" name="3" required="required" class="ui-dform-text"></div><h3 id="html-2" name="2" class="ui-dform-h3">Your Feedback</h3><div class="form-group"><label for="28" class="ui-dform-label dform-label-required">Report Type</label><select id="28" data-sort="" name="28" required="required" class="ui-dform-select"><option value="">Please Select</option><option selected="selected" value="Broken link or Page Not Found">Broken link or Page Not Found</option><option value="Spelling mistake">Spelling mistake</option><option value="Out of date content">Out of date content</option><option value="General error">General error</option></select></div><div class="form-group"><label for="8" class="ui-dform-label dform-label-required">Your comments</label><textarea id="8" data-sort="" name="8" help="Please give us your comments" required="required" class="ui-dform-textarea"></textarea></div><p id="html-9" name="9" class="ui-dform-p">The address of the last page you visited is<br />http://www.aber.ac.uk/en/news/archive/?from=globalnav -&gt; https://www.aber.ac.uk/en/news/archive/expanding_content.js</p><div class="form-group hidden"><label class="ui-dform-label" for="31">The address of the last page you visited is</label><input type="text" id="30" name="30" value="http://www.aber.ac.uk/en/news/archive/?from=globalnav -&gt; https://www.aber.ac.uk/en/news/archive/expanding_content.js"/></div><div class="form-group"><label for="29" class="ui-dform-label">If your feedback relates to a page other than this, then please enter address (URI) here</label><input type="text" id="29" data-sort="" name="29" class="ui-dform-text"></div><div class="form-group"><label for="31" class="ui-dform-label">If you are human leave the following empty</label><input type="text" id="31" data-sort="" name="31" class="ui-dform-text"></div><div class="form-group"><input type="hidden" id="937" value="404 Page" data-sort="" name="937" required="required" class="ui-dform-hidden"></div><input type="hidden" name="no-js" id="no-js" value="true"><input type="hidden" name="redirect_uri" id="redirect_uri" value="/en/"><input type="hidden" name="questionset_id" id="questionset_id" value="10"><div><p class="ui-dform-p"><small>The University will process the personal data collected via this form on the basis of your consent (Article 6(1)(a) GDPR).</small></p>
<p class="ui-dform-p"><small>Your personal data will be used by the Information Services in order to respond to your enquiry.</small></p>

</div><input type="submit" class="ui-dform-submit" value="Continue"></form><div id="gdpr-decleration" class="hidden"><p class="ui-dform-p"><small>The University will process the personal data collected via this form on the basis of your consent (Article 6(1)(a) GDPR).</small></p>
<p class="ui-dform-p"><small>Your personal data will be used by the Information Services in order to respond to your enquiry.</small></p>

</div>
<div id='addition-backup' class='hidden'><p id="html-9" name="9" class="ui-dform-p">The address of the last page you visited is<br />http://www.aber.ac.uk/en/news/archive/?from=globalnav -&gt; https://www.aber.ac.uk/en/news/archive/expanding_content.js</p><div class="form-group hidden"><label class="ui-dform-label" for="31">The address of the last page you visited is</label><input type="text" id="30" name="30" value="http://www.aber.ac.uk/en/news/archive/?from=globalnav -&gt; https://www.aber.ac.uk/en/news/archive/expanding_content.js"/></div></div>
</div><div id="form-rule-init"><script type="text/javascript">
var language="en";
var vals=null;
var form_rule=decodeURIComponent("%7B%22rules%22%3A%5B%7B%22if%22%3A%5B%7B%22id%22%3A%220%22%7D%2C%7B%22%231%22%3A%5B%7B%22value%22%3A%22%3D%3D''%22%2C%22observe%22%3A%22change%22%7D%5D%7D%2C%7B%22action%22%3A%7B%22hide%22%3A%22%2331%22%7D%7D%2C%7B%22action%22%3A%7B%22hide%22%3A%22label%5Bfor%3D'31'%5D%22%7D%7D%5D%7D%5D%7D");
var formId = '10';
var antiSpam = [10,183];
var startTime = new Date().getTime()/1000;
runYourFunctionWhenJQueryIsLoaded();
function runYourFunctionWhenJQueryIsLoaded()
{
	if (window.jQuery)
    { 	jQuery( document ).ready(function()
		{  	jQuery.getScript( "/formbuilder-assets/js/jquery.formvalues.js" )
			.done(function( script, textStatus )
			{	vals = jQuery("#enForm").values();
				if(jQuery('#cyForm').length)
				{	vals = jQuery("#cyForm").values();
					language="cy";
				}
			});
			jQuery.getScript( "/formbuilder-assets/js/jquery.dform/dist/jquery.validate.js" )
			.done(function( script, textStatus )
			{	jQuery.getScript( "/formbuilder-assets/js/jquery.dform/dist/jquery.dform-1.1.0.js" )
				.done(function( script, textStatus )
				{	run_dform();
					try
					{	if (form_callback && typeof(form_callback) == "function")
						{	form_callback();
						}

					}
					catch(err) {
					//console.log("no callbacks")
					}
					jQuery.getScript( "/formbuilder-assets/js/form_rules.js" )
					.done(function( script, textStatus )
					{	//console.log(form_rule);
						if(form_rule)
						{
						parseData(form_rule)  ;
						}
					});
					jQuery.getScript( "/formbuilder-assets/js/formbuilder.js" );
				});
			});
		});
    }
    else
    {   setTimeout(runYourFunctionWhenJQueryIsLoaded, 50);
    }
}

function run_dform(){
  if($.inArray( formId, antiSpam )){
    $(".ui-dform-form").validate({
      submitHandler: function(form) {
        var myTime =  parseInt( new Date().getTime()/1000 - startTime )
        $('#completion-time').val(myTime);
        if( $(".ui-dform-form textarea").length > 0 ){
            // client side spam checking can be used if we choose to in the future
            // if( $(".ui-dform-form textarea").eq(0).isAberSpam()){
            //     return false;
            // }
        }
        form.submit();
      }
    });
  }

 
	var en='{"action":"/en/form-manager/feedback/","method":"post","html":[{"id":"questionset_id", "name":"questionset_id", "type":"hidden", "value":"10"},{"id":"redirect_uri", "name":"redirect_uri", "type":"hidden", "value":"/en/"},{"id":"html-1","name":"1","type":"h3","html":"Your Details"},{"id":"1", "data-sort":"", "name":"1","type":"text","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"caption":"Forename(s)" },{"id":"2", "data-sort":"", "name":"2","type":"text","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"caption":"Surname" },{"id":"3", "data-sort":"", "name":"3","type":"text","validate" : {"required" : true, "email" : true, "messages" : { "required" : "Required input", "email" : "Must be a valid email address"}},"caption":"Email Address" },{"id":"html-2","name":"2","type":"h3","html":"Your Feedback"},{"id":"28", "data-sort":"", "name":"28","type":"select","required" : "required" ,"caption":"Report Type","options":{"":"Please Select","Broken link or Page Not Found":"Broken link or Page Not Found","Spelling mistake":"Spelling mistake","Out of date content":"Out of date content","General error":"General error"} },{"id":"8", "data-sort":"", "name":"8","type":"textarea","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"help":"Please give us your comments","caption":"Your comments" },{"id":"html-7","name":"7","type":"p","html":"webapp_needle"},{"id":"29", "data-sort":"", "name":"29","type":"text","validate" : { "required" : false, "messages" : {"required" : "Required input"}},"caption":"If your feedback relates to a page other than this, then please enter address (URI) here" },{"id":"31", "data-sort":"", "name":"31","type":"text","validate" : { "required" : false, "messages" : {"required" : "Required input"}},"caption":"If you are human leave the following empty" },{"id":"937", "data-sort":"", "name":"937","type":"hidden","required" : "required" ,"caption":"source" },{"type":"submit","value":"Continue"}]}';
	var cy='{"action":"/en/form-manager/feedback/","method":"post","html":[{"id":"questionset_id", "name":"questionset_id", "type":"hidden", "value":"10"},{"id":"redirect_uri", "name":"redirect_uri", "type":"hidden", "value":"/en/"},{"id":"html-1","name":"1","type":"h3","html":"Eich Manylion"},{"id":"1", "data-sort":"","name":"1","type":"text","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"caption":"Enw(au) cyntaf" },{"id":"2", "data-sort":"","name":"2","type":"text","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"caption":"Cyfenw" },{"id":"3", "data-sort":"","name":"3","type":"text","validate" : {"required" : true, "email" : true, "messages" : { "required" : "Required input", "email" : "Must be a valid email address"}},"caption":"Cyfeiriad e-bost" },{"id":"html-2","name":"2","type":"h3","html":"Eich Adborth"},{"id":"28", "data-sort":"","name":"28","type":"select","required" : "required" ,"caption":"Math o adroddiad","options":{"":"Dewiswch","Broken link or Page Not Found":"Dolen diffygiol neu tudalen heb ei ddarganfod","Spelling mistake":"Camsillafu","Out of date content":"Deunydd allan o ddyddiad","General error":"Gwall cyffredinol"} },{"id":"8", "data-sort":"","name":"8","type":"textarea","validate" : { "required" : true, "messages" : {"required" : "Required input"}},"help":"A fyddech cystal &#226; nodi eich sylwadau","caption":"Eich sylwadau" },{"id":"html-7","name":"7","type":"p","html":"webapp_needle"},{"id":"29", "data-sort":"","name":"29","type":"text","validate" : { "required" : false, "messages" : {"required" : "Required input"}},"caption":"Os ydyw\'r adborth yn ymwneud a tudalen gwahanol i hyn yna rhowch fanylion" },{"id":"31", "data-sort":"","name":"31","type":"text","validate" : { "required" : false, "messages" : {"required" : "Required input"}},"caption":"Os ydych yn ddynol gadewch y gofod canlynol yn wag" },{"id":"937", "data-sort":"","name":"937","type":"hidden","required" : "required" ,"caption":"fynhonell" },{"type":"submit","value":"Ymlaen"}]}';


 if(jQuery('#enForm').length){
   jQuery('#enForm').html('');
   en=en.replace(/&quot;/g,'"');
   en=en.replace(', ,', ',');
   var en_load=jQuery.parseJSON(en);
   if($.inArray( formId, antiSpam )){
     en_load.html.unshift({"id":"csrf_token","name":"csrf_token","type":"hidden","value":"___noise___ 1001"});
     en_load.html.unshift({"id":"completion-time","name":"completion_time","type":"hidden","value":"99"});
   }
   jQuery("#enForm").dform(en_load);
 }

 if(jQuery('#cyForm').length){
   jQuery('#cyForm').html('');
   cy=cy.replace(/&quot;/g,'"');
   cy=cy.replace(', ,', ',');
   var cy_load=jQuery.parseJSON(cy);
   if($.inArray( formId, antiSpam )){
     cy_load.html.unshift({"id":"csrf_token","name":"csrf_token","type":"hidden","value":"___noise___ 1000"});
     cy_load.html.unshift({"id":"completion-time","name":"completion_time","type":"hidden","value":"99"});
   }
   jQuery("#cyForm").dform(cy_load);
 }
	jQuery(".ui-dform-form *").filter(':input').each(function(){
		if(jQuery(this).attr("required") == "required")
		{	var label = jQuery("label[for='"+jQuery(this).attr('id')+"']");
			jQuery(label).addClass("dform-label-required");
		}
	});
	jQuery(".ui-dform-radiobuttons").each(function(){
			if(jQuery(this).attr("required") == "required")
			{ jQuery(this).removeAttr("required");
				jQuery(this).find("input").each(function(){
				jQuery(this).attr("required","required");
				});
			}
		});

	jQuery(".ui-dform-checkboxes").each(function(){
			if(jQuery(this).attr("required") == "required")
			{ jQuery(this).removeAttr("required");
				jQuery(this).find("input").each(function(){
				jQuery(this).attr("required","required");
				name=jQuery(this).attr("name")+'[]';
				jQuery(this).attr("name", name);

				});
			}
		});

	jQuery("div.wForm h3").each(function()
	{	if(!jQuery(this).next().is('div') && !jQuery(this).next().is('p') && !jQuery(this).next().is('h4')) {
				jQuery(this).remove();
		}
	});
	jQuery("div.wForm h4").each(function()
	{	if(!jQuery(this).next().is('div') && !jQuery(this).next().is('p')) {
			jQuery(this).remove();
		}
	});
	jQuery(".ui-dform-p").each(function()
	{	p_content=jQuery(this).html();
		if(p_content.indexOf("[a"))
		{	p_content=p_content.replace("[a", "<a class='dform_p_link'");
			p_content=p_content.replace("[/a]", "</a>");
			p_content=p_content.replace("]", ">");
			jQuery(this).html(p_content);
		}
	});
	if(jQuery(".ui-dform-submit").prev().is('h3') || jQuery(".ui-dform-submit").prev().is('h4'))
	{	jQuery(".ui-dform-submit").prev().remove();
	}
	jQuery("form.au-form :input").each(function(){
		if (jQuery(this).attr('type') =="radio" || jQuery(this).attr('type') =="checkbox")
		{	if (jQuery(this).attr('type') =="radio")
			{	that=jQuery(this).closest('.ui-dform-radiobuttons');
			}
			if (jQuery(this).attr('type') =="checkbox")
			{	that=jQuery(this).closest('.ui-dform-checkboxes');
			}
			var help_message = jQuery(that).attr('help');
			if(typeof help_message !== 'undefined' && help_message !== false)
			{	var elem='<span data-hint="'+help_message+'" class="radio-check-hint radio-check-hint2 hint--bottom">?</span>';
				//parent_label=jQuery(that).closest('.ui-dform-label');
				jQuery(elem).insertBefore(that);
				jQuery(that).removeAttr('help');
			}
		}
		else
		{	var help_message = jQuery(this).attr('help');
			if(typeof help_message !== 'undefined' && help_message !== false)
			{	var elem='<spacn data-for="'+jQuery(this).attr('id')+'" data-hint="'+help_message+'" class="hint--bottom">?</span>';
				jQuery(elem).insertAfter(this);
				jQuery(this).removeAttr('help');
			}
		}

	});
	if(jQuery("#2200").length)
	{	setTimeout("clearConfession();",150);
	}
	jQuery('#'+language+'Form').values(vals);
	setTimeout("fix_help_position();", 200);
	if(typeof d_form_datepicker == 'function'){
		setTimeout("d_form_datepicker();", 200);
	}
	if(typeof formmanager_callback == 'function'){
		formmanager_callback();
	}
	if (jQuery("body").hasClass("departmental-x-switchover") || jQuery("body").hasClass("departmental-x-corporate")) {
        jQuery('div.form-group').each(function(){
			jQuery(this).addClass("fm-au-generic");
        });
    }
    else
    {	jQuery('div.form-group').each(function(){
			jQuery(this).addClass("fm-snow-white");
        });
    }
    try
	{	if (autocomplete_callback && typeof(autocomplete_callback) == "function")
		{	autocomplete_callback();
		}
	}
	catch(err) {
		//console.log("no autocomplete callbacks")
	}
    setTimeout("checkPresets();",450);
}

function checkPresets(){
  var form_presets=null;

  if(form_presets!==null)
  {       $.each(form_presets, function(key, preset){
                switch(preset.type) {
                        case "text":
                        case "textarea":
                        case "email":
                        case "password":
                                $('#'+preset.input).val(preset.value);
				$('#'+preset.input).trigger("click");
				$('#'+preset.input).trigger("change");
                                break;
                            case "select":
                                $("#"+preset.input).val(preset.value);
				//$("#"+preset.input+" option[value=" + preset.value + "]").prop('selected', true);
				$("#"+preset.input).trigger("click");
				$("#"+preset.input).trigger("change");
                                break;
                        case "checkbox":
                        case "radio":
                                $("input[name="+preset.input+"][value=" + preset.value + "]").prop('checked', true);
				$("input[name="+preset.input+"][value=" + preset.value + "]").trigger("click");
				$("input[name="+preset.input+"][value=" + preset.value + "]").trigger("change");
                                break;
                        default:
                                // code block
                }
        });
  }
	try
	{	if (presets_callback && typeof(presets_callback) == "function")
		{	presets_callback();
		}
	}
	catch(err) {
		//console.log("no callbacks")
	}

}

function clearConfession()
{
	jQuery("#2200").val('');
	jQuery("#2200").parent().addClass('hidden');
}

function fix_help_position()
{	jQuery(".ui-dform-radiobuttons").nextAll('.radio-check-hint:first').each(function(){
		height=jQuery(this).prev().height();
		height=height-65;
		jQuery(this).attr("style", "top:-"+height+"px;");
	});
}

</script><style>
.radio-check-hint2
{	margin-top:-2em!important;
}

fieldset.ui-dform-fieldset
{	width: 100%;
}
.ui-dform-form legend.dform-legend{

	font-size:13pt;
}
.ui-dform-form legend.dform-legend-required:after {
    content: " *";
    color: red;
}
fieldset.ui-dform-fieldset legend.dform-legend
{	margin-top:1em;
    padding: 1em 0 0 0;
	color:rgb(78, 78, 78);
	font-weight:bold;
	font-size:16px;
}
</style></div></div></div></aside></article></div></main>
<!-- END main -->
<footer>
<div class="inner"><div class="footer-main"><div class="inner"><div class="footer-primary-container"><div class="nav-footer"><ul><li><a href="//www.aber.ac.uk/en/study-with-us/?from=footer">Study with us</a></li><li><a href="//www.aber.ac.uk/en/international/?from=footer">International</a></li><li><a href="//www.aber.ac.uk/en/research/?from=footer">Research</a></li><li><a href="//www.aber.ac.uk/en/news/?from=footer">News</a></li><li><a href="//www.aber.ac.uk/en/development/?from=footer">Alumni</a></li><li><a href="//www.aber.ac.uk/en/about-us/?from=footer">About Us</a></li></ul></div><!-- END .footer-nav --><div class="nav-secondary-footer"><ul><li><a href="//www.aber.ac.uk/en/student/?from=footer">Information for Students</a></li><li><a href="//www.aber.ac.uk/en/staff/?from=footer">Information for Staff</a></li><li><a href="//www.aber.ac.uk/en/hr/jobs/?from=footer">Jobs</a></li><li><a href="//www.aber.ac.uk/en/departments/?from=footer">Departments</a></li></ul></div><!-- END .footer-nav-secondary --><div class="contact-footer"><ul><li><a href="//www.aber.ac.uk/en/contact-us/?from=footer">Contact</a></li></ul><p><abbr title="Telephone">T</abbr>: +44 (0)1970 622900</p><p class="address">Aberystwyth University, Reception, Penglais, Aberystwyth, Ceredigion, SY23 3FL</p><p><a href="//www.aber.ac.uk/en/contact-us/?from=footer">Send us a message</a></p><ul class="social-media"><li><a class="sm-facebook" href="//www.facebook.com/aberystwyth.university">Facebook</a></li><li><a class="sm-youtube" href="//www.youtube.com/user/aberystwythuni">YouTube</a></li><li><a class="sm-twitter" href="//twitter.com/AberUni">Twitter</a></li><li><a class="sm-instagram" href="//www.instagram.com/aberystwyth.university/">Instagram</a></li></ul></div><!-- END .footer-contact --><div class="map-footer"><ul><li><a href="//www.aber.ac.uk/en/maps-travel/">Maps &amp; Travel</a></li></ul><a href="//www.aber.ac.uk/en/maps-travel/"><img src="/img/footer/aber-map.png" srcset="/img/footer/aber-map.png, /img/footer/aber-map@2x.png 2x" alt="Maps and travel"></a></div><!-- END .footer-maps --></div><!-- END .footer-primary --><div class="carousel-footer-container"><div class="carousel-footer"><a href="https://www.aber.ac.uk/en/news/archive/2019/09/title-225842-en.html"><img alt="Good University Guide 2020 - Welsh University of the year" src="/img/footer/gug-20-en.png"></a><a href="//www.aber.ac.uk/en/gug/"><img alt="Good University Guide 2019 - University of the year for teaching quality" src="/img/footer/gug-19-en.png"></a><!-- <a href="https://www.aber.ac.uk/en/news/archive/2018/06/title-213752-en.html">
           <img alt="TEF Gold award" src="/img/footer/tef-en.png">
         </a> --><a href="http://www.qaa.ac.uk/reviewing-higher-education/quality-assurance-reports/Aberystwyth-University"><img alt="QAA Quality Mark thumbnail" src="/img/footer/qaa.png"></a><a href="https://www.cyberaware.gov.uk/cyberessentials/"><img alt="Cyber essentials" oncontextmenu="return false;" src="/img/footer/cyber.png"></a><a href="https://www.accessable.co.uk/organisations/aberystwyth-university"><img alt="AccessAble Access Guide" src="/img/footer/access-en.png"></a><a href="https://www.aber.ac.uk/en/equality/disability-confident/"><img alt="Disability Confident Employer" src="/img/footer/disability-en.png"></a></div></div><!-- END .footer-logos --></div></div><div class="footer-secondary-container"><div><div class="inner"><ul><li><a href="#page-start">^ Back to top</a></li><li><a href="/en/cookie-policy/?from=footer" title="Cookie Policy">Cookie Policy</a></li><li><a accesskey="3" href="/en/site-map/?from=footer" title="A text map of this web site.">Site Map</a></li><li><a accesskey="0" href="/en/accessibility/?from=foooter" title="Accessibility information">Accessibility</a></li><li><a accesskey="8" href="/en/terms-and-conditions/?from=footer" title="Terms &amp; Conditions, including information on copyright and privacy.">Terms &amp; Conditions</a></li><li><a accesskey="9" href="/en/feedback/?from=footer" title="Send us feedback on this web site.">Web Site Feedback</a></li><li><a href="/en/corporate-information/finance-procurement/#Modern%20Slavery%20Statement" title="Modern Slavery Statement">Modern Slavery Statement</a></li><li><p>&copy;2022 Aberystwyth University. Registered charity: No 1145141</p></li></ul></div></div></div><div class="t4Edit-page-container"></div></div>
<!--FROM APP FOOTER-->
 </footer><link rel="stylesheet" href="/css2/fonts.css" type="text/css" media="all" />
            <!-- END footer -->
        </div>
        <!-- END site-wrapper -->

        <!--[if gte IE 9]><!-->
            <!-- Using version 1 for consistency with IE8 version in <head> -->
          <script type="text/javascript" src="//www.aber.ac.uk/js2/libs/jquery/3.5.1/jquery-3.5.1.min.js"></script>
        <!--<![endif]-->
        <script type="text/javascript" src="/js2/plugins.v4.min.js"></script>
        <script type="text/javascript" src="/js2/main.v4.min.js"></script>
        <script src="/feedback-test-resources/feedback.js"></script>
		<script ttype="text/plain" data-cookieconsent="statistics">
			setTimeout(function(){var a=document.createElement("script");
			var b=document.getElementsByTagName("script")[0];
			a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0013/5182.js?"+Math.floor(new Date().getTime()/3600000);
			a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
		</script>
		<!-- Facebook Pixel Code -->
		<script type="text/plain" data-cookieconsent="marketing">
		!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
		n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
		document,'script','https://connect.facebook.net/en_US/fbevents.js');
		fbq('init', '1633955860255539');
		fbq('track', 'PageView');
		</script>
		<!-- DO NOT MODIFY -->
		<!-- End Facebook Pixel Code -->
    </body>
</html>


